import java.util.ArrayList;

import weka.core.Instances;

public class GradiantDecent {
	
	private ArrayList<Double> theta;
	private ArrayList<ArrayList<Double>> data;
	
	private double learningRate;
	private int itterations;
	private int noOfParameters;
	private int maxItteration;
	private boolean useRegularization=false;
	private double lembda;
	
	public GradiantDecent(Instances dataSet, double learningRate,int maxItteration) {
		super();
		setData(dataSet);
		this.learningRate = learningRate;
		this.itterations = 0;
		this.maxItteration = maxItteration;
		this.noOfParameters = data.get(0).size()-1;
		System.out.println(noOfParameters+"::::::");
	}


	public GradiantDecent() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	


	public GradiantDecent(ArrayList<ArrayList<Double>> data, double learningRate, int maxItteration,
			boolean useRegularization, double lembda) {
		super();
		this.data = data;
		this.learningRate = learningRate;
		this.maxItteration = maxItteration;
		this.useRegularization = useRegularization;
		this.lembda = lembda;
		this.noOfParameters = data.get(0).size()-1;
	}


	public int getMaxItteration() {
		return maxItteration;
	}


	public void setMaxItteration(int maxItteration) {
		this.maxItteration = maxItteration;
	}


	public boolean isUseRegularization() {
		return useRegularization;
	}


	public void setUseRegularization(boolean useRegularization) {
		this.useRegularization = useRegularization;
	}


	public double getLembda() {
		return lembda;
	}


	public void setLembda(double lembda) {
		this.lembda = lembda;
	}


	public ArrayList<Double> getTheta() {
		return theta;
	}


	public void setTheta(ArrayList<Double> theta) {
		this.theta = theta;
	}


	public ArrayList<ArrayList<Double>> getData() {
		return data;
	}


	public void setData(ArrayList<ArrayList<Double>> dataSet) {
		this.data = dataSet;
		noOfParameters = data.get(0).size()-1;
	}

	
	public void setData(Instances dataSet) {
		data=new ArrayList<ArrayList<Double>>();
		int noOfInstances = dataSet.numInstances();
		int noOfAtributes = dataSet.numAttributes();
		ArrayList<Double> parameters;
		for(int index=0;index<noOfInstances;index++){
			parameters = new ArrayList<Double>();
			parameters.add(1.0);
			for(int atributeIndex=0;atributeIndex<noOfAtributes;atributeIndex++){
				parameters.add(dataSet.instance(index).value(atributeIndex));
			}
			data.add(parameters);
		}
	}

	public double getLearningRate() {
		return learningRate;
	}


	public void setLearningRate(double learningRate) {
		this.learningRate = learningRate;
	}


	public int getItterations() {
		return itterations;
	}


	public void setItterations(int itterations) {
		this.itterations = itterations;
	}
	
	public double cost(ArrayList<Double> parameters,int classLabel){
		double probability = this.predictY(parameters);
		double logHXY1=Math.log(probability);
		double logHXY0=Math.log(1-probability);
		return -((classLabel*logHXY1) + ((1-classLabel) * logHXY0)); 
		
	}


	public double calculateJTheta(){
		int length=data.size();
		double cost=0;
		for(int i=0;i<length;i++){
			ArrayList<Double> parameters = new ArrayList<Double>();
			Double classValue = data.get(i).get(noOfParameters);
			parameters.addAll(data.get(i));
			parameters.remove(noOfParameters);
			cost+= Math.pow(classValue - predictY(parameters),2);
			
		}
		if(isUseRegularization()){
			cost+=penalty();
		}
		cost= cost/(float)length;
		return cost;
	}
	
	private double penalty() {
		// TODO Auto-generated method stub
		
		int length=theta.size();
		double penalty=0;
		for(int i=1;i<length;i++){
			penalty+=(theta.get(i)*theta.get(i));
		}
		
		return penalty*lembda;
	}


	public double PartialDerivative(int parameterIdex){
		
		double sum =0;
		int length = data.size();
		for(int index = 0; index<length; index++){
			sum+=(predictY(data.get(index))-data.get(index).get(theta.size()))*data.get(index).get(parameterIdex);
		}
		return sum*getLearningRate()/length;
	}
	
	public double getThetaTX(ArrayList<Double> datas){
		double value = 0;
		int length=theta.size();
		for(int index=0;index<length;index++){
			value+=theta.get(index)*datas.get(index);
		}
		return value;
	}
	
	public double predictY(ArrayList<Double> values) {
		double power =getThetaTX(values);
		double value=0;
		value=1.0/(1.0+Math.pow(Math.E, -power));
		return value;
	}
	
	public void update(){
		ArrayList<Double> tempTheta=new ArrayList<Double>();
		for(int index = 0;index<noOfParameters;index++){
			if(index==0 || !isUseRegularization()){
				tempTheta.add(theta.get(index) - PartialDerivative(index));
			}
			else{
				double multiplier = 1 - (learningRate*lembda/data.size());
				tempTheta.add((theta.get(index)*multiplier)-PartialDerivative(index));
			}
		}
		theta=tempTheta;
	}
	
	public ArrayList<Double> gradientDescenntSearch(){
		initThetas();
		ArrayList<Double> returnList=new ArrayList<>();
		while(true){
			update();
			itterations++;
			returnList.add(calculateJTheta());
			if(itterations==maxItteration){
				break;
			}
		}
		printReport();
		return returnList;
	}
	
	private void initThetas() {
		// TODO Auto-generated method stub
		theta = new ArrayList<Double>();
		for(int index = 0;index<noOfParameters;index++){
			theta.add(0.0);
			System.out.println("Theta"+index+" initialized with value: " + theta.get(index));
		}
		System.out.println(calculateJTheta());
	}
	
	
	public void initThetas1() {
		// TODO Auto-generated method stub
		theta = new ArrayList<Double>();
			theta.add(0.24525679410584325);
			theta.add(0.4150498369834917);
			theta.add(0.9832964537028734);
	}


	public void printReport() {
		System.out.println("Gradient Descent Algorithm executed results are:");
		System.out.println("learning rate: "+getLearningRate());
		System.out.println("Number of iteration: "+getItterations());
		System.out.println("Final values of theta");
		for(int index = 0; index<noOfParameters;index++){
			System.out.print("theta"+index+": "+theta.get(index)+"\t");
		}
		System.out.println("final RMSE: "+ calculateJTheta());
	}

}
