import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class StartScriptProject extends JFrame {
	
	public StartScriptProject() {

        initUI();
    }

    private void initUI() {
        
        setTitle("Linear regression");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		try {
			 Class.forName("com.mysql.jdbc.Driver");
			conn =
				       DriverManager.getConnection("jdbc:mysql://localhost/cs638db?" +
				                                   "user=root&password=root");
			String query = "select distinct KC from kdd_data";
			
			String query1= "select c.anon_student_id,count1/count10 from (select a.anon_student_id,count(*) as count10 from kdd_data a group by a.anon_student_id) c, (select a1.anon_student_id,count(*) as count1 from kdd_data a1 where correct_first_attempt = 1 group by a1.anon_student_id) b where c.anon_student_id = b.anon_student_id";
			
			stmt = conn.createStatement();
			HashMap<String,Double> set = new HashMap<String,Double>();
			HashMap<String,Double> set2 = new HashMap<String,Double>();
			HashMap<String,Double> set1 = new HashMap<String,Double>();
			
			if(true){
				rs=stmt.executeQuery(query1);
				while(rs.next()){
					set.put(rs.getString(1), rs.getDouble(2));
					
				}
			}	
			rs.close();
			rs= stmt.executeQuery(query);
			if(rs!=null){
				while(rs.next()){
					String kc=rs.getString(1);
					String[] kcs = kc.split("~~");
					int l=kcs.length;
					for(int i = 0 ;i<l;i++){
						if(set1.containsKey(kcs[i])){
							double j = set1.get(kcs[i]);
							set1.remove(kcs[i]);
							set1.put(kcs[i], j+1.0);
						}
						else{
							set1.put(kcs[i],1.0);
						}
					}
					
				}
			}
			for(String k: set1.keySet()){
				//System.out.println(k +" :: "+ set1.get(k));
				
				String q="select count(1),correct_first_attempt from kdd_data where KC like '%"+k+"%' group by correct_first_attempt";
				rs.close();
				rs = stmt.executeQuery(q);
				double countTotal=0;
				double count1=0;
				
				while(rs.next()){
					if(rs.getInt(2)==1){
						count1= rs.getDouble(1);
					}
					countTotal+= rs.getDouble(1);
				}
				set2.put(k, count1/countTotal);
			}
			
			
			rs.close();
			ArrayList<ArrayList<Double>> datas = new ArrayList<ArrayList<Double>>();
			
			ArrayList<ArrayList<Object>> datas1 = new ArrayList<ArrayList<Object>>();
			String query2 = "select anon_student_id,correct_first_attempt,KC,row from kdd_data order by row";
			rs=stmt.executeQuery(query2);
			while(rs.next()){
				ArrayList<Double> data = new ArrayList<Double>();
				ArrayList<Object> data1 = new ArrayList<Object>();
				String[] KC= rs.getString(3).split("~~");
				double value = rs.getDouble(2);
				double prob = 1;
				for(String k: KC){
					prob*= set2.get(k);
					
				}
				data.add(1.0);
				data.add(set.get(rs.getString(1)));
				data.add(prob);
				data.add(value);
				
				
				data1.add(rs.getString(4));
				data1.add(rs.getString(1));
				data1.add(prob);
				
				datas.add(data);
				datas1.add(data1);
				
			}
			GradiantDecent grad = new GradiantDecent(datas, 0.08, 500, false, 0);
			
			
			
//			StartScriptProject script=new StartScriptProject();
//			
//			ArrayList<Double> costs=grad.gradientDescenntSearch();
//			ChartPanel panel = script.createCostChart(costs);
//			panel = script.createCostChart(costs);
//			script.setContentPane(panel);
//			script.setVisible(true);
			grad.initThetas1();
			FileHandller handller = new FileHandller();
			int i =0;
			for(ArrayList<Object> d:datas1){
				int row = Integer.parseInt((String) d.get(0));
				handller.generateResultFile(row, (String) d.get(1), grad.predictY(datas.get(i)));
				i++;
				System.out.println(row);
			}
			handller.destroy();
			
 		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
	private ChartPanel createCostChart(ArrayList<Double> costs) {
		XYLineAndShapeRenderer rendrer = new XYLineAndShapeRenderer( );
		rendrer.setSeriesPaint( 0 , Color.BLUE );
    	rendrer.setSeriesStroke(0, new BasicStroke(1.0f)); 
		JFreeChart chart = ChartFactory.createXYLineChart("", "itterations", "cost", this.createDataset(costs));
		ChartPanel panel=new ChartPanel(chart);
		panel.setPreferredSize(new Dimension(800, 600));
		return panel;
	}
	
	private XYDataset createDataset( ArrayList<Double> cost)
	   {
		XYSeries data = new XYSeries("learning rate");
		XYSeriesCollection dataset=new XYSeriesCollection();
		int length = cost.size();
		for(int i=0;i<length;i++){
			data.add(i, cost.get(i));
		}
		dataset.addSeries(data);
		return (dataset);
	   }
	
}
