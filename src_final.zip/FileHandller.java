import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class FileHandller {
	
	PrintWriter out = null;
	
	public FileHandller() throws FileNotFoundException {
		// TODO Auto-generated constructor stub
		out = new PrintWriter("result1.txt");
	}
	
	public void generateResultFile(int row, String studentId, double cfaProbability)
	{
		try
		{
			String result = row + "," + studentId + "," + cfaProbability;
			
			out.println(result);
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void destroy(){
		out.close();
	}
	
	public static void main(String gg[])
	{
		FileHandller handler;
		try {
			handler = new FileHandller();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		handler.generateResultFile(1, "abcd", 0.0198);
		handler.generateResultFile(2, "abcd", 0.0198);
		handler.generateResultFile(3, "abcd", 0.0198);
		System.out.println("Done");
		handler.destroy();
	}
}